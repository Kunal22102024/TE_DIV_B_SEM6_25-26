# Ops Context

## What this workspace is for
Running the app locally, environment setup, and demo-day checklist.

## First-time setup

### 1. Get your free Gemini API key
- Go to https://aistudio.google.com/app/apikey
- Sign in with Google, click "Create API Key"
- No credit card. No billing. Free.
- Paste it into .env as GEMINI_API_KEY

### 2. Gmail OAuth setup
Run this once to get your refresh token:
```bash
python ops/scripts/gmail_auth.py
```
It will open a browser, ask you to sign in, and print your refresh token.
Paste GMAIL_CLIENT_ID, GMAIL_CLIENT_SECRET, GMAIL_REFRESH_TOKEN into .env.

### 3. Supabase setup
- Create free project at https://supabase.com
- Run the SQL in ops/scripts/create_table.sql in the Supabase SQL editor
- Copy project URL and anon key into .env

### 4. Install dependencies
```bash
cd src/backend
pip install -r requirements.txt
```

### 5. Run backend
```bash
uvicorn main:app --reload --port 8000
```

### 6. Run frontend
Open src/frontend/index.html directly in browser, or use VS Code Live Server.

### 7. Trigger a manual poll (during demo)
```bash
curl -X POST http://localhost:8000/poll
```

## requirements.txt (backend)
```
fastapi
uvicorn
supabase
instructor
google-generativeai
google-auth-oauthlib
google-auth-httplib2
google-api-python-client
python-dotenv
apscheduler
pydantic
```

## Demo day checklist
- [ ] GEMINI_API_KEY is in .env and working
- [ ] Gmail OAuth refresh token is in .env
- [ ] Supabase table created and empty (fresh start for demo)
- [ ] Backend starts cleanly on port 8000
- [ ] Frontend loads in browser
- [ ] 5 seeded test emails sent to Gmail inbox (see below)
- [ ] Manual /poll tested — leads appear in dashboard
- [ ] Approve flow tested — status changes to Sent
- [ ] Follow-up email actually arrives in test inbox

## Seeded test emails to send yourself before demo
Send these from a throwaway Gmail to your demo inbox.

1. **Hot** — Subject: "Urgent: Need solution this week"
   Body: "Our current vendor just failed us on a critical project. Budget is approved,
   decision maker is available, we need to move fast. Can we talk today or tomorrow?"

2. **Warm** — Subject: "Interested in your product"
   Body: "We've been evaluating a few tools for our team. Yours came up in our research.
   Timeline is probably next quarter. Would love a walkthrough."

3. **Warm** — Subject: "Saw your demo, want to learn more"
   Body: "Caught your demo last week. Looks interesting for what we're trying to do.
   When do you have time for a call?"

4. **Cold** — Subject: "Pricing question"
   Body: "Can you send over pricing info? Thanks."

5. **Cold** — Subject: "Just browsing"
   Body: "Not sure if we need this yet but wanted to check it out."
