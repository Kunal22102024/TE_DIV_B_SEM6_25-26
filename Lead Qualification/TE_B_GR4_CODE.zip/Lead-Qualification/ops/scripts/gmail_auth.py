"""One-time OAuth flow to obtain a Gmail refresh token.

Run this once:
    python ops/scripts/gmail_auth.py

It opens a browser for Google sign-in, then prints the refresh token
so you can paste it into .env as GMAIL_REFRESH_TOKEN.
"""

import os
import sys

from dotenv import load_dotenv
from google_auth_oauthlib.flow import InstalledAppFlow

load_dotenv()

SCOPES = ["https://mail.google.com/"]


def main() -> None:
    client_id = os.getenv("GMAIL_CLIENT_ID")
    client_secret = os.getenv("GMAIL_CLIENT_SECRET")

    if not client_id or not client_secret:
        print("ERROR: Set GMAIL_CLIENT_ID and GMAIL_CLIENT_SECRET in .env first.")
        sys.exit(1)

    client_config = {
        "installed": {
            "client_id": client_id,
            "client_secret": client_secret,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "redirect_uris": ["http://localhost:8080/"],
        }
    }

    flow = InstalledAppFlow.from_client_config(client_config, scopes=SCOPES)
    creds = flow.run_local_server(port=8080, access_type="offline", prompt="consent")

    if not creds.refresh_token:
        print("ERROR: No refresh token received. Try revoking access and running again:")
        print("       https://myaccount.google.com/permissions")
        sys.exit(1)

    print()
    print("=" * 60)
    print("SUCCESS — paste this into your .env file:")
    print("=" * 60)
    print()
    print(f"GMAIL_REFRESH_TOKEN={creds.refresh_token}")
    print()


if __name__ == "__main__":
    main()