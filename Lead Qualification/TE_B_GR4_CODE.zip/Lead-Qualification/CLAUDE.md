# Lead Qualifier

AI-powered lead qualification tool that reads Gmail, scores urgency via Llama 3.3 70B on Groq, and auto follows-up on approval.

## Tech Stack
- Backend: FastAPI, Python, Supabase (Postgres), Instructor, Groq SDK, APScheduler
- Frontend: React (no framework), plain CSS
- Email: Gmail API (read + send)
- LLM: Llama 3.3 70B via Groq API + Instructor for structured outputs (free tier)

## Workspaces
- /planning — Architecture decisions, data models, feature specs
- /src — All application code (backend + frontend)
- /docs — API reference, setup guide, demo script
- /ops — Environment setup, run scripts, demo-day checklist

## Routing Table
| Task | Go to | Read | Notes |
|------|-------|------|-------|
| Plan a feature or change | /planning | CONTEXT.md | Check /decisions before changing architecture |
| Write backend code | /src/backend | CONTEXT.md | Follow patterns in models.py and llm.py |
| Write frontend code | /src/frontend | CONTEXT.md | One page app, no routing library |
| Write or fix tests | /src/tests | CONTEXT.md | Use pytest, mock Gmail and Groq calls |
| Setup or run the app | /ops | CONTEXT.md | Check .env.example first |
| Write docs or demo prep | /docs | CONTEXT.md | Panel demo script lives here |

## Naming Conventions
- Python files: snake_case
- React components: PascalCase
- Specs: feature-name_spec.md
- Decision records: YYYY-MM-DD-decision-title.md
- Env vars: SCREAMING_SNAKE_CASE
