# Docs Context

## What this workspace is for
Panel demo script, API reference, and setup guide.
Prep the demo script before Friday — it matters more than perfect code.

## Demo script outline (expand into docs/demo-script.md)

### Opening (30 seconds)
"Sales teams waste hours chasing low-quality leads. This tool reads incoming
lead emails, scores urgency using an LLM, and drafts follow-up emails that
a human approves before anything gets sent."

### Step 1 — Show the dashboard
- Three columns: Hot / Warm / Cold
- Each card shows: sender, subject, 1-line summary, urgency badge
- "Gemini read each email and categorised it automatically"

### Step 2 — Click into a Hot lead
- Show full analysis: urgency score, key signals, reasoning
- "It explains *why* it scored this hot — not just a number. Auditable."

### Step 3 — Approve and send
- Click Approve on a Hot lead
- Show the pre-written follow-up email in the modal
- Click Confirm → status changes to Sent
- "The human stays in the loop. Nothing sends without approval."

### Step 4 — Explain the pipeline (for technical questions)
- Gmail API polls inbox every 5 minutes
- Each email → Gemini 2.0 Flash with a strict Pydantic output schema via Instructor
- Result stored in Supabase, rendered in React
- Approval triggers Gmail send

## Panel Q&A prep
| Question | Answer |
|----------|--------|
| Why Gemini? | Free tier (1,500 req/day), fast, Instructor support for structured outputs |
| Why Instructor? | Forces LLM to return valid Pydantic schema — no manual JSON parsing or retries |
| How does it handle spam? | Score 1–2 = Cold column, ignored unless manually reviewed |
| Could this scale? | Swap Gmail polling for SendGrid inbound webhook, add auth, deploy to Railway |
| What's the accuracy? | Show the reasoning field — every decision is explainable |
| Why not just use keywords? | LLM understands context and tone, not just trigger words |

## API reference
| Endpoint | Method | Purpose |
|----------|--------|---------|
| /leads | GET | All leads sorted by urgency_score desc |
| /leads/{id} | GET | Single lead with full analysis |
| /leads/{id}/approve | POST | Approve lead, trigger follow-up send |
| /leads/{id}/reject | POST | Mark as rejected |
| /poll | POST | Manually trigger Gmail poll (use this during demo) |
