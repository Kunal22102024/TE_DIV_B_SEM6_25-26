# 2026-03-19 Use Gemini 2.0 Flash via Instructor

## Decision
Use Google Gemini 2.0 Flash as the LLM, accessed via the Instructor library.

## Why Gemini Flash (not Anthropic, not OpenAI)
- Free tier at Google AI Studio: 1,500 requests/day, no credit card required
- Gemini 2.0 Flash is fast and accurate enough for email urgency analysis
- Instructor has first-class support for Gemini via `instructor.from_gemini()`
- No cost risk during development or demo

## Why Instructor (not raw SDK)
- Forces Gemini to return a valid Pydantic schema — no manual JSON parsing
- Auto-retries if model returns malformed output
- LeadAnalysis becomes the single source of truth for both LLM and DB layers
- Switching LLM providers later (e.g. to Anthropic) is a 2-line change

## How to get the API key
https://aistudio.google.com/app/apikey — sign in with Google, create key, done.

## What this affects
- src/backend/llm.py (implementation)
- src/backend/models.py (LeadAnalysis schema)
- src/CONTEXT.md (LLM pattern section)
- .env.example (GEMINI_API_KEY)
