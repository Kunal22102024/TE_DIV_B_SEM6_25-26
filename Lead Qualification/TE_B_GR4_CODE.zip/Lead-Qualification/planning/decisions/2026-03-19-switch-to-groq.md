# 2026-03-19 Switch from Gemini to Groq

## Decision
Replace Google Gemini 2.0 Flash with Llama 3.3 70B on Groq as the LLM provider.

## Why we switched
- Gemini free tier returned `limit:0` quota errors — unusable without billing setup
- Groq works immediately after creating a free API key at https://console.groq.com
- No time to debug Google quota issues with the demo deadline on Friday

## Why Llama 3.3 70B Versatile
- Available on Groq's free tier with generous rate limits
- Strong instruction-following for structured JSON output via Instructor
- Fast inference on Groq hardware — well under 2s per lead analysis

## What changed
- src/backend/llm.py — `instructor.from_groq(Groq(...))` replaces `instructor.from_gemini(...)`
- src/backend/models.py — no changes (LeadAnalysis schema is provider-agnostic)
- .env / .env.example — `GROQ_API_KEY` replaces `GEMINI_API_KEY`
- CLAUDE.md — updated Tech Stack and LLM line
- src/CONTEXT.md — updated LLM pattern, backend rules, env vars
- planning/CONTEXT.md — updated pipeline and architectural principles
