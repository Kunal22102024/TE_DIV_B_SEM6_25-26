# 2026-03-19 Use Instructor for all LLM calls

## Decision
All Claude API calls go through the Instructor library, not the raw Anthropic SDK.

## Why
- Instructor enforces Pydantic output schemas automatically
- No need to parse or validate LLM JSON manually
- If the model returns malformed output, Instructor retries — not our code
- Makes LeadAnalysis a single source of truth shared by LLM and DB layers

## Consequence
Never call `anthropic.messages.create()` directly in application code.
Always use `instructor.from_anthropic(client).chat.completions.create()`.

## What this affects
- src/backend/llm.py (implementation)
- src/backend/models.py (schema definition)
- planning/CONTEXT.md (architectural principles)
