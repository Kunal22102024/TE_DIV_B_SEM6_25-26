# Planning Context

## What this workspace is for
Architecture decisions, data model design, and feature specs before writing code.
Check /decisions before proposing changes that affect the DB schema or LLM output shape.

## Current project status
Building MVP for college panel demo. Single test user, no auth, no multi-tenancy.
Deadline: Friday (demo day).

## Core data flow
Gmail inbox → Poll every 5 min → FastAPI ingestion
→ Llama 3.3 70B via Groq (via Instructor) → LeadAnalysis structured output
→ Supabase → React dashboard (urgency columns: Hot / Warm / Cold)
→ User approves → Claude generates follow-up draft → Gmail sends it

## Supabase schema (leads table)
| Column | Type | Notes |
|--------|------|-------|
| id | uuid | primary key |
| email_from | text | sender address |
| email_subject | text | |
| email_body | text | full plain text |
| urgency_score | int | 1–5 |
| urgency_label | text | hot / warm / cold |
| summary | text | 1-2 sentence plain English |
| key_signals | text[] | array of signal strings |
| suggested_followup | text | draft reply body |
| reasoning | text | why this score (for panel) |
| status | text | pending / approved / sent |
| received_at | timestamptz | |
| followed_up_at | timestamptz | nullable |

## LeadAnalysis Pydantic model (source of truth)
Do not change this shape without also updating the Supabase schema and frontend rendering.

```python
class LeadAnalysis(BaseModel):
    urgency_score: int        # 1–5
    urgency_label: str        # "hot" | "warm" | "cold"
    summary: str              # 1-2 sentences
    key_signals: list[str]    # signals that drove this score
    suggested_followup: str   # full draft reply email body
    reasoning: str            # plain English explanation for panel
```

## Architectural principles
- LLM logic lives only in llm.py — never inline in routes
- All LLM outputs go through Pydantic models via Instructor
- Use Instructor with Groq — never call the Groq SDK directly
- Gmail logic lives only in email_client.py
- Frontend talks to backend via REST only — no direct Supabase access from React
- Groq free tier is more than enough for a demo
