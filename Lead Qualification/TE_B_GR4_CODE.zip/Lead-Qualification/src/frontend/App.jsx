const { useState, useEffect, useCallback } = React;

const API = "http://localhost:8000";

function UrgencyBadge({ label }) {
  return <span className={`urgency-badge ${label}`}>{label}</span>;
}

function LeadCard({ lead, onApprove, onReject }) {
  const label = lead.urgency_label;
  const isDone = lead.status !== "pending";

  return (
    <div className={`lead-card ${label}`}>
      <div className="lead-from">{lead.email_from}</div>
      <div className="lead-subject">{lead.email_subject}</div>
      <div className="lead-summary">{lead.summary}</div>

      <div className="lead-meta">
        <UrgencyBadge label={label} />
        <span className="score-badge">{lead.urgency_score}/5</span>
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", gap: "0px", marginBottom: "4px" }}>
        {lead.key_signals.map((s, i) => (
          <span className="signal-tag" key={i}>{s}</span>
        ))}
      </div>

      {isDone ? (
        <div className={`status-badge status-${lead.status}`}>
          {lead.status === "sent" ? "Sent" : lead.status === "approved" ? "Approved" : "Rejected"}
        </div>
      ) : (
        <div className="card-actions">
          <button className="btn btn-approve" onClick={() => onApprove(lead)}>
            Approve
          </button>
          <button className="btn btn-reject" onClick={() => onReject(lead.id)}>
            Reject
          </button>
        </div>
      )}
    </div>
  );
}

function ApproveModal({ lead, onConfirm, onCancel, loading }) {
  if (!lead) return null;

  return (
    <div className="modal-overlay" onClick={onCancel}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h3>Re: {lead.email_subject}</h3>
        <div className="modal-from">To: {lead.email_from}</div>

        <div className="modal-section-label">Reasoning</div>
        <div className="modal-reasoning">{lead.reasoning}</div>

        <div className="modal-section-label">Suggested Follow-up</div>
        <div className="modal-followup">{lead.suggested_followup}</div>

        <div className="modal-actions">
          <button className="btn btn-cancel" onClick={onCancel} disabled={loading}>
            Cancel
          </button>
          <button className="btn btn-confirm" onClick={onConfirm} disabled={loading}>
            {loading ? "Sending…" : "Confirm Send"}
          </button>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [leads, setLeads] = useState([]);
  const [modalLead, setModalLead] = useState(null);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);

  const fetchLeads = useCallback(async () => {
    try {
      const res = await fetch(`${API}/leads`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setLeads(data.leads.filter((l) => l.status === "pending"));
      setError(null);
    } catch (err) {
      console.error("Failed to fetch leads:", err);
      setError("Could not connect to backend");
    }
  }, []);

  useEffect(() => {
    fetchLeads();
    const interval = setInterval(fetchLeads, 30000);
    return () => clearInterval(interval);
  }, [fetchLeads]);

  const handleApprove = async () => {
    if (!modalLead) return;
    setSending(true);
    try {
      const res = await fetch(`${API}/leads/${modalLead.id}/approve`, { method: "POST" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setLeads((prev) => prev.filter((l) => l.id !== data.id));
      setModalLead(null);
    } catch (err) {
      console.error("Approve failed:", err);
    } finally {
      setSending(false);
    }
  };

  const handleReject = async (id) => {
    try {
      const res = await fetch(`${API}/leads/${id}/reject`, { method: "POST" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setLeads((prev) => prev.filter((l) => l.id !== data.id));
    } catch (err) {
      console.error("Reject failed:", err);
    }
  };

  const pending = leads.filter((l) => l.status === "pending");
  const hot  = pending.filter((l) => l.urgency_score >= 4);
  const warm = pending.filter((l) => l.urgency_score === 3);
  const cold = pending.filter((l) => l.urgency_score <= 2);

  return (
    <React.Fragment>
      {/* Top bar */}
      <div className="topbar">
        <div className="topbar-left">
          <h1>Lead<span>Qualifier</span></h1>
        </div>
        <div className="poll-indicator">
          <div className="pulse-dot"></div>
          polling active
        </div>
      </div>

      {/* Stats */}
      <div className="stats-row">
        <div className="stat-card">
          <div className="stat-label">Total Leads</div>
          <div className="stat-value">{pending.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label" style={{ color: "var(--hot)" }}>Hot</div>
          <div className="stat-value">{hot.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label" style={{ color: "var(--warm)" }}>Warm</div>
          <div className="stat-value">{warm.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label" style={{ color: "var(--cold)" }}>Cold</div>
          <div className="stat-value">{cold.length}</div>
        </div>
      </div>

      {error && (
        <div style={{
          background: "rgba(232,64,64,0.1)", border: "1px solid rgba(232,64,64,0.3)",
          borderRadius: "8px", padding: "12px 18px", marginBottom: "24px",
          fontSize: "13px", color: "var(--red)"
        }}>
          {error}
        </div>
      )}

      {/* Columns */}
      <div className="columns">
        <div>
          <div className="column-header">
            <h2 style={{ color: "var(--hot)" }}>Hot</h2>
            <span className="column-count">{hot.length}</span>
          </div>
          {hot.map((l) => (
            <LeadCard key={l.id} lead={l} onApprove={setModalLead} onReject={handleReject} />
          ))}
        </div>

        <div>
          <div className="column-header">
            <h2 style={{ color: "var(--warm)" }}>Warm</h2>
            <span className="column-count">{warm.length}</span>
          </div>
          {warm.map((l) => (
            <LeadCard key={l.id} lead={l} onApprove={setModalLead} onReject={handleReject} />
          ))}
        </div>

        <div>
          <div className="column-header">
            <h2 style={{ color: "var(--cold)" }}>Cold</h2>
            <span className="column-count">{cold.length}</span>
          </div>
          {cold.map((l) => (
            <LeadCard key={l.id} lead={l} onApprove={setModalLead} onReject={handleReject} />
          ))}
        </div>
      </div>

      {/* Approve modal */}
      <ApproveModal
        lead={modalLead}
        onConfirm={handleApprove}
        onCancel={() => setModalLead(null)}
        loading={sending}
      />
    </React.Fragment>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
