"""All Groq API calls via Instructor. Nothing else."""

import logging
import os

import instructor
from groq import Groq
from dotenv import load_dotenv

from models import LeadAnalysis

load_dotenv()
logger = logging.getLogger(__name__)

client = instructor.from_groq(Groq(api_key=os.getenv("GROQ_API_KEY")))

SYSTEM_PROMPT = (
    "You are a lead-qualification assistant. Given an inbound email, "
    "produce a structured analysis.\n\n"
    "Rules:\n"
    "- urgency_score: 1 (spam/irrelevant) to 5 (ready-to-buy, time-sensitive).\n"
    "- urgency_label: 'hot' if score >= 4, 'warm' if score == 3, 'cold' if score <= 2.\n"
    "- summary: 1-2 sentences, plain English, no jargon.\n"
    "- key_signals: list the concrete phrases or facts that drove the score.\n"
    "- suggested_followup: a complete, professional reply email body "
    "the user can send as-is.\n"
    "- reasoning: explain why you chose this score so a human reviewer "
    "can verify quickly."
)


def analyze_lead(email_body: str, email_subject: str) -> LeadAnalysis:
    """Run Groq via Instructor and return a validated LeadAnalysis."""
    try:
        return client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            response_model=LeadAnalysis,
            messages=[{
                "role": "user",
                "content": (
                    f"{SYSTEM_PROMPT}\n\n"
                    f"Subject: {email_subject}\n\n"
                    f"{email_body}"
                ),
            }],
        )
    except Exception:
        logger.exception("Groq analysis failed for subject=%r", email_subject)
        raise