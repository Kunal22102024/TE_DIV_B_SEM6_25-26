"""Gmail polling and sending. Nothing else."""

import base64
import logging
import os
from email.mime.text import MIMEText

from dotenv import load_dotenv
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

load_dotenv()
logger = logging.getLogger(__name__)

SCOPES = ["https://mail.google.com/"]
TOKEN_URI = "https://oauth2.googleapis.com/token"


def _get_gmail_service():
    creds = Credentials(
        token=None,
        refresh_token=os.getenv("GMAIL_REFRESH_TOKEN"),
        token_uri=TOKEN_URI,
        client_id=os.getenv("GMAIL_CLIENT_ID"),
        client_secret=os.getenv("GMAIL_CLIENT_SECRET"),
        scopes=SCOPES,
    )
    return build("gmail", "v1", credentials=creds)


def _extract_header(headers: list[dict], name: str) -> str:
    for h in headers:
        if h["name"].lower() == name.lower():
            return h["value"]
    return ""


def _extract_plain_body(payload: dict) -> str:
    """Walk the MIME tree and return the first text/plain part."""
    if payload.get("mimeType") == "text/plain" and payload.get("body", {}).get("data"):
        return base64.urlsafe_b64decode(payload["body"]["data"]).decode("utf-8", errors="replace")

    for part in payload.get("parts", []):
        result = _extract_plain_body(part)
        if result:
            return result

    return ""


def poll_inbox() -> list[dict]:
    """Fetch unread inbox emails, mark each as read, return list of dicts.

    Each dict has keys: from_email, subject, body.
    """
    try:
        service = _get_gmail_service()

        response = (
            service.users()
            .messages()
            .list(userId="me", q="is:unread", labelIds=["INBOX"], maxResults=10)
            .execute()
        )
        message_ids = [m["id"] for m in response.get("messages", [])]

        if not message_ids:
            logger.info("No unread emails found")
            return []

        results: list[dict] = []

        for msg_id in message_ids:
            msg = (
                service.users()
                .messages()
                .get(userId="me", id=msg_id, format="full")
                .execute()
            )

            headers = msg.get("payload", {}).get("headers", [])
            from_email = _extract_header(headers, "From")
            subject = _extract_header(headers, "Subject")
            body = _extract_plain_body(msg.get("payload", {}))

            results.append({
                "from_email": from_email,
                "subject": subject,
                "body": body,
            })

            service.users().messages().modify(
                userId="me",
                id=msg_id,
                body={"removeLabelIds": ["UNREAD"]},
            ).execute()

        logger.info("Polled %d new emails", len(results))
        return results

    except Exception:
        logger.exception("Gmail poll failed")
        raise


def send_email(to: str, subject: str, body: str) -> None:
    """Send a plain-text email via the authenticated Gmail account."""
    try:
        service = _get_gmail_service()

        message = MIMEText(body)
        message["To"] = to
        message["Subject"] = subject
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")

        service.users().messages().send(
            userId="me",
            body={"raw": raw},
        ).execute()

        logger.info("Sent email to %s subject=%r", to, subject)

    except Exception:
        logger.exception("Gmail send failed to=%s subject=%r", to, subject)
        raise
