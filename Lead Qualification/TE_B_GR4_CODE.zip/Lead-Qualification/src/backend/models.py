"""Single source of truth for all Pydantic models.

LeadAnalysis is the LLM output schema — do not change its shape without also
updating the Supabase schema and frontend rendering (see planning/CONTEXT.md).
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field


class UrgencyLabel(str, Enum):
    HOT = "hot"
    WARM = "warm"
    COLD = "cold"


# ---------------------------------------------------------------------------
# LLM output model — used by Instructor in llm.py
# ---------------------------------------------------------------------------

class LeadAnalysis(BaseModel):
    urgency_score: int = Field(..., ge=1, le=5, description="Urgency from 1 (low) to 5 (critical)")
    urgency_label: UrgencyLabel = Field(..., description="Bucket derived from score")
    summary: str = Field(..., description="1-2 sentence plain English summary")
    key_signals: list[str] = Field(..., description="Signals that drove this score")
    suggested_followup: str = Field(..., description="Full draft reply email body")
    reasoning: str = Field(..., description="Plain English explanation for the panel")


# ---------------------------------------------------------------------------
# Database / API models
# ---------------------------------------------------------------------------

class LeadStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    SENT = "sent"


class LeadBase(BaseModel):
    email_from: str
    email_subject: str
    email_body: str


class LeadCreate(LeadBase):
    """Payload assembled internally after polling Gmail + running LLM analysis."""

    urgency_score: int = Field(..., ge=1, le=5)
    urgency_label: UrgencyLabel
    summary: str
    key_signals: list[str]
    suggested_followup: str
    reasoning: str
    status: LeadStatus = LeadStatus.PENDING
    received_at: datetime


class LeadRecord(LeadBase):
    """Full lead row as returned from Supabase / the API."""

    id: UUID
    urgency_score: int = Field(..., ge=1, le=5)
    urgency_label: UrgencyLabel
    summary: str
    key_signals: list[str]
    suggested_followup: str
    reasoning: str
    status: LeadStatus
    received_at: datetime
    followed_up_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class LeadListResponse(BaseModel):
    """GET /leads response wrapper."""

    leads: list[LeadRecord]


class ApproveResponse(BaseModel):
    """POST /leads/{id}/approve response."""

    id: UUID
    status: LeadStatus
    followed_up_at: Optional[datetime] = None
