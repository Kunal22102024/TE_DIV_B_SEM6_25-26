"""Supabase client, all DB reads/writes."""

import logging
import os
from datetime import datetime, timezone
from uuid import UUID

from dotenv import load_dotenv
from supabase import Client, create_client

from models import LeadCreate, LeadRecord, LeadStatus

load_dotenv()
logger = logging.getLogger(__name__)

TABLE = "leads"

supabase: Client = create_client(
    os.getenv("SUPABASE_URL", ""),
    os.getenv("SUPABASE_KEY", ""),
)


def insert_lead(lead: LeadCreate) -> LeadRecord:
    """Insert a new lead row and return the full record with its generated id."""
    payload = lead.model_dump(mode="json")
    response = supabase.table(TABLE).insert(payload).execute()
    row = response.data[0]
    return LeadRecord(**row)


def get_all_leads() -> list[LeadRecord]:
    """Return every lead, highest urgency first."""
    response = (
        supabase.table(TABLE)
        .select("*")
        .order("urgency_score", desc=True)
        .execute()
    )
    return [LeadRecord(**row) for row in response.data]


def get_lead_by_id(lead_id: UUID) -> LeadRecord:
    """Fetch a single lead by primary key. Raises if not found."""
    response = (
        supabase.table(TABLE)
        .select("*")
        .eq("id", str(lead_id))
        .single()
        .execute()
    )
    return LeadRecord(**response.data)


def update_lead_status(lead_id: UUID, status: LeadStatus) -> None:
    """Set the status column (pending / approved / sent)."""
    supabase.table(TABLE).update(
        {"status": status.value}
    ).eq("id", str(lead_id)).execute()


def set_followed_up_at(lead_id: UUID) -> None:
    """Stamp the current UTC time into followed_up_at."""
    supabase.table(TABLE).update(
        {"followed_up_at": datetime.now(timezone.utc).isoformat()}
    ).eq("id", str(lead_id)).execute()
