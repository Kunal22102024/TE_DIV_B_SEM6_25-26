"""FastAPI app, all route definitions."""

import logging
from datetime import datetime, timezone
from uuid import UUID

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from database import (
    get_all_leads,
    get_lead_by_id,
    insert_lead,
    set_followed_up_at,
    update_lead_status,
)
from email_client import poll_inbox, send_email
from llm import analyze_lead
from models import (
    ApproveResponse,
    LeadCreate,
    LeadListResponse,
    LeadRecord,
    LeadStatus,
)
from scheduler import lifespan

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Lead Qualifier", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/leads", response_model=LeadListResponse)
def list_leads():
    leads = get_all_leads()
    return LeadListResponse(leads=leads)


@app.get("/leads/{lead_id}", response_model=LeadRecord)
def read_lead(lead_id: UUID):
    try:
        return get_lead_by_id(lead_id)
    except Exception:
        raise HTTPException(status_code=404, detail="Lead not found")


@app.post("/leads/{lead_id}/approve", response_model=ApproveResponse)
def approve_lead(lead_id: UUID):
    try:
        lead = get_lead_by_id(lead_id)
    except Exception:
        raise HTTPException(status_code=404, detail="Lead not found")

    if lead.status != LeadStatus.PENDING:
        raise HTTPException(
            status_code=400,
            detail=f"Lead is already {lead.status.value}",
        )

    update_lead_status(lead_id, LeadStatus.APPROVED)

    try:
        send_email(
            to=lead.email_from,
            subject=f"Re: {lead.email_subject}",
            body=lead.suggested_followup,
        )
        update_lead_status(lead_id, LeadStatus.SENT)
        set_followed_up_at(lead_id)
    except Exception:
        logger.exception("Follow-up send failed for lead %s", lead_id)

    updated = get_lead_by_id(lead_id)
    return ApproveResponse(
        id=updated.id,
        status=updated.status,
        followed_up_at=updated.followed_up_at,
    )


@app.post("/leads/{lead_id}/reject", response_model=ApproveResponse)
def reject_lead(lead_id: UUID):
    try:
        lead = get_lead_by_id(lead_id)
    except Exception:
        raise HTTPException(status_code=404, detail="Lead not found")

    if lead.status != LeadStatus.PENDING:
        raise HTTPException(
            status_code=400,
            detail=f"Lead is already {lead.status.value}",
        )

    update_lead_status(lead_id, LeadStatus.REJECTED)
    updated = get_lead_by_id(lead_id)
    return ApproveResponse(
        id=updated.id,
        status=updated.status,
        followed_up_at=updated.followed_up_at,
    )


@app.post("/poll")
def trigger_poll():
    emails = poll_inbox()
    processed = 0

    for email in emails:
        try:
            analysis = analyze_lead(
                email_body=email["body"],
                email_subject=email["subject"],
            )

            lead = LeadCreate(
                email_from=email["from_email"],
                email_subject=email["subject"],
                email_body=email["body"],
                urgency_score=analysis.urgency_score,
                urgency_label=analysis.urgency_label,
                summary=analysis.summary,
                key_signals=analysis.key_signals,
                suggested_followup=analysis.suggested_followup,
                reasoning=analysis.reasoning,
                received_at=datetime.now(timezone.utc),
            )

            insert_lead(lead)
            processed += 1
        except Exception:
            logger.exception(
                "Failed to process email from=%s subject=%r",
                email.get("from_email"),
                email.get("subject"),
            )

    return {"processed": processed, "total": len(emails)}
