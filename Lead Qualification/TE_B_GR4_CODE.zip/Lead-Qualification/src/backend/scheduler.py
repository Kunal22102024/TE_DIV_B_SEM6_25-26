"""APScheduler — runs email polling loop every POLL_INTERVAL_SECONDS."""

import logging
import os
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from apscheduler.schedulers.background import BackgroundScheduler
from dotenv import load_dotenv
from fastapi import FastAPI

from database import insert_lead
from email_client import poll_inbox
from llm import analyze_lead
from models import LeadCreate

load_dotenv()
logger = logging.getLogger(__name__)

scheduler = BackgroundScheduler()


def _poll_and_process() -> None:
    """Fetch unread emails, analyze each, and insert into the database."""
    logger.info("Scheduled poll starting")
    try:
        emails = poll_inbox()
    except Exception:
        logger.exception("Scheduled poll: inbox fetch failed")
        return

    processed = 0
    for email in emails:
        try:
            analysis = analyze_lead(
                email_body=email["body"],
                email_subject=email["subject"],
            )
            lead = LeadCreate(
                email_from=email["from_email"],
                email_subject=email["subject"],
                email_body=email["body"],
                urgency_score=analysis.urgency_score,
                urgency_label=analysis.urgency_label,
                summary=analysis.summary,
                key_signals=analysis.key_signals,
                suggested_followup=analysis.suggested_followup,
                reasoning=analysis.reasoning,
                received_at=datetime.now(timezone.utc),
            )
            insert_lead(lead)
            processed += 1
        except Exception:
            logger.exception(
                "Scheduled poll: failed to process email from=%s subject=%r",
                email.get("from_email"),
                email.get("subject"),
            )

    logger.info("Scheduled poll done: %d/%d processed", processed, len(emails))


@asynccontextmanager
async def lifespan(app: FastAPI):
    interval = int(os.getenv("POLL_INTERVAL_SECONDS", "300"))
    scheduler.add_job(_poll_and_process, "interval", seconds=interval)
    scheduler.start()
    logger.info("Scheduler started — polling every %d seconds", interval)
    yield
    scheduler.shutdown(wait=False)
    logger.info("Scheduler shut down")
