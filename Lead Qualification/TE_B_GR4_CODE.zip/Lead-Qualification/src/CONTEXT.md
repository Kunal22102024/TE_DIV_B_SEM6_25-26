# Src Context

## What this workspace is for
All application code. Backend is FastAPI + Python. Frontend is React with no framework.

## Backend structure (src/backend/)
| File | Purpose |
|------|---------|
| main.py | FastAPI app, all route definitions |
| models.py | Single source of truth for all Pydantic models |
| llm.py | All Groq API calls via Instructor. Nothing else. |
| email_client.py | Gmail polling and sending. Nothing else. |
| database.py | Supabase client, all DB reads/writes |
| scheduler.py | APScheduler — runs email polling loop every 5 min |

## Frontend structure (src/frontend/)
Single page app. No React Router. No component library.
| File | Purpose |
|------|---------|
| index.html | Entry point |
| App.jsx | Root — fetches leads, manages state |
| components/LeadCard.jsx | Individual lead display with summary + signals |
| components/UrgencyBadge.jsx | hot/warm/cold colored badge |
| components/ApproveModal.jsx | Shows suggested_followup text, confirm button |

## LLM pattern — always use this exact pattern in llm.py
```python
import instructor
from groq import Groq
from models import LeadAnalysis

client = instructor.from_groq(Groq(api_key=os.getenv("GROQ_API_KEY")))

def analyze_lead(email_body: str, email_subject: str) -> LeadAnalysis:
    return client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        response_model=LeadAnalysis,
        messages=[{
            "role": "user",
            "content": f"...{email_subject}...{email_body}"
        }]
    )
```

## Backend coding rules
- Use Instructor for every LLM call — never call the Groq SDK directly
- Use python-dotenv for all env vars — never hardcode keys
- All routes return JSON with Pydantic response models
- Wrap Gmail and LLM calls in try/except — log failures, don't crash the server
- Gmail polls on a 5-minute APScheduler interval

## Frontend coding rules
- Fetch from FastAPI backend only (localhost:8000 in dev)
- Leads grouped into three columns: Hot / Warm / Cold
- Approve button opens modal showing suggested_followup text
- Confirmed approval calls POST /leads/{id}/approve
- No CSS framework — plain CSS, clean for the demo

## Testing rules (src/tests/)
- Use pytest
- Mock all external calls: Gmail API, Groq API, Supabase
- Must test: LeadAnalysis parsing, urgency label mapping, approve route

## Required env vars
```
# Get this free at https://console.groq.com
GROQ_API_KEY=
GMAIL_CLIENT_ID=
GMAIL_CLIENT_SECRET=
GMAIL_REFRESH_TOKEN=
SUPABASE_URL=
SUPABASE_KEY=
POLL_INTERVAL_SECONDS=300
```
